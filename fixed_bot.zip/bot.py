#!/usr/bin/env python3
import os
import logging
import telebot
from flask import Flask

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

TOKEN = os.environ.get("BOT_TOKEN")
if not TOKEN:
    raise RuntimeError("BOT_TOKEN environment variable is missing.")

bot = telebot.TeleBot(TOKEN, parse_mode="HTML")
app = Flask(__name__)

@bot.message_handler(commands=["start"])
def start(message):
    bot.reply_to(
        message,
        "✅ Bot is running.\n\n"
        "Send a message to test the bot."
    )

@bot.message_handler(func=lambda message: True, content_types=["text"])
def handle_message(message):
    bot.reply_to(message, "✅ Message received.")

@app.get("/")
def health():
    return "Bot is running!", 200

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))

    # Run Telegram polling in a background thread so the HTTP health endpoint
    # remains available on hosting platforms.
    import threading
    threading.Thread(target=bot.infinity_polling, daemon=True).start()

    app.run(host="0.0.0.0", port=port)
